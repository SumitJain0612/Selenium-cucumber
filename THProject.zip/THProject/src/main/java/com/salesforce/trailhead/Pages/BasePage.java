package com.salesforce.trailhead.Pages;

import org.openqa.selenium.WebDriver;

/**
 * Created by sjain on 10/24/18.
 */
public class BasePage {
    WebDriver webDriver;

    public BasePage(WebDriver webDriver) {
        this.webDriver = webDriver;
    }


}
