package com.salesforce.trailhead.Pages;

import org.openqa.selenium.WebDriver;

/**
 * Created by sjain on 10/24/18.
 */
public class TrailHeadHomePage extends BasePage {
    public TrailHeadHomePage(WebDriver webDriver) {
        super(webDriver);
    }

    public boolean isTrailHeadHomePageLoaded(){
        //check if trail head home page is loaded after login
        return true;
    }

    public void clickModuleTab(){
        //click on the module tab from the trail head home page
    }
}
