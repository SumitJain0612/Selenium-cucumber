package com.salesforce.trailhead.Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

/**
 * Created by sjain on 10/24/18.
 */

@CucumberOptions(
        features = {"/Users/sjain/THProject/src/test/java/FeatureFiles"},
        glue ={"com.salesforce.trailhead.StepsDefinition"}
)
public class TestRunner extends AbstractTestNGCucumberTests {


}
