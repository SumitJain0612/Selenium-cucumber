package com.salesforce.trailhead.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created by sjain on 10/24/18.
 */
public class ModulePage extends BasePage {
    public ModulePage(WebDriver webDriver) {
        super(webDriver);
    }

    public boolean isModulePageLoaded(){
        try {
            webDriver.findElement(By.cssSelector("button[class='th-color--ice slds-button th-text--small clear-filter th-text--underline slds-m-left_medium']"));
            return true;
        }catch (NoSuchElementException exp){
            return false;
        }
    }
    public boolean addFavorite(String moduleName){
        List<WebElement> list = webDriver.findElements(By.cssSelector("article[class='tile tile-type-module"));

        for (int i = 0; i <list.size() ; i++) {
            WebElement webElement = list.get(i);
            if(webElement.findElement(By.cssSelector("a[title='tile-title]")).getText().contains(moduleName)){
                webElement.findElement(By.cssSelector("li[data-react-class='favorites/FavoritesButton'")).click();
                return true;
            }
        }
        return false;
    }

    public boolean verifyAddFavouriteConformationMessage(){
        //once module is marked as favourite, verify the green pop up confirmation on the page
        return true;
    }

    public boolean verifyFavoriteModule(String moduleName){
        //verify whether selected module is marked as favorite.
        return true;
    }
}
