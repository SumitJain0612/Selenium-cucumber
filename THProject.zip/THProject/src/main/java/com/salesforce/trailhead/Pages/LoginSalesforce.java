package com.salesforce.trailhead.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Created by sjain on 10/24/18.
 */
public class LoginSalesforce extends BasePage {
    public LoginSalesforce(WebDriver webDriver) {
        super(webDriver);
    }

    public void enterUserName(String userName){
        webDriver.findElement(By.id("username")).sendKeys(userName);
    }

    public void enterPassword(String password){
        webDriver.findElement(By.id("password")).sendKeys(password);
    }

    public void clickLogin(){
        webDriver.findElement(By.id("Login")).click();
    }
}
