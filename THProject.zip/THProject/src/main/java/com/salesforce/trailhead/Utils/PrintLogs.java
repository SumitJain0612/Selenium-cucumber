package com.salesforce.trailhead.Utils;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.log4j.Logger;
import org.testng.*;

/**
 * Created by sjain on 10/24/18.
 */
public class PrintLogs {

    Class className;
    Logger logger;


    public PrintLogs(Class clazz) {
        this.className = clazz;
        logger = Logger.getLogger(clazz);
    }

    public synchronized void info(String message) {
        try {
            ExtentTestManager.getTest().log(LogStatus.INFO, className.getName() + "--" + message);
        } catch (Exception exp) {
            String testType = getTestType();
            ExtentTest test = ExtentTestManager.getTest(testType);
            if (test != null)
                test.log(LogStatus.INFO, className.getName() + "--" + message);
        }
        logger.info(message);
    }

    public synchronized void pass(String message) {
        try {
            ExtentTestManager.getTest().log(LogStatus.PASS, className.getName() + "--" + message);
        } catch (Exception exp) {
            String testType = getTestType();
            ExtentTest test = ExtentTestManager.getTest(testType);
            if (test != null)
                test.log(LogStatus.PASS, className.getName() + "--" + message);
        }
        logger.info(message);
    }

    public synchronized void error(String message) {
        try {
            ExtentTestManager.getTest().log(LogStatus.ERROR, "Failed......." + className.getName() + "--" + message);
        } catch (Exception exp) {
            String testType = getTestType();
            ExtentTest test = ExtentTestManager.getTest(testType);
            if (test != null)
                test.log(LogStatus.ERROR, "Failed......." + className.getName() + "--" + message);
        }
        logger.error("Failed..." + message);
    }

    public synchronized void warn(String message) {
        try {
            ExtentTestManager.getTest().log(LogStatus.WARNING, className.getName() + "--" + message);
        } catch (Exception exp) {
//            logger.error("Not able to print using extent manager, message " + exp.getMessage());
        }
        logger.warn(message);
    }

    public synchronized void debug(String message) {
        try {
            ExtentTestManager.getTest().log(LogStatus.INFO, className.getName() + "--" + message);
        } catch (Exception exp) {
//            logger.error("Not able to print using extent manager, message " + exp.getMessage());
        }
        logger.debug(message);
    }

    public synchronized String getTestType() {
        try {
            String test = (String) Reporter.getCurrentTestResult().getParameters()[0];
            return test;
        } catch (Exception exp) {
            return null;
        }


    }

}
