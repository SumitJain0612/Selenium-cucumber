package com.salesforce.trailhead.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

/**
 * Created by sjain on 10/24/18.
 */
public class TrailHeadPage extends BasePage {

    public TrailHeadPage(WebDriver webDriver) {
        super(webDriver);
    }

    public  void navigateToHomePage(){
        webDriver.get("https://trailhead.salesforce.com/en");
//        webDriver.navigate().to("https://trailhead.salesforce.com/en");
        webDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    public void clickOnLogin(){
        webDriver.findElement(By.cssSelector("button[value='login']")).click();
    }

    public void clickOnSalesforceLogin(){
        webDriver.findElement(By.cssSelector("a[class='th-modal-btn th-modal-btn__salesforce']")).click();
//        webDriver.findElement(By.className("th-modal-btn th-modal-btn__salesforce")).click();
    }
}
