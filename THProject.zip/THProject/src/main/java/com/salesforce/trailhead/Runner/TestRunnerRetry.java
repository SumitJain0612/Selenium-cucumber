package com.salesforce.trailhead.Runner;


import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import com.github.mkolisnyk.cucumber.runner.RetryAcceptance;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;

/**
 * Created by sjain on 10/24/18.
 */

//this file is completely taken from web from http://mkolisnyk.github.io/cucumber-reports/failed-tests-rerun

//@RunWith(ExtendedCucumber.class)

@ExtendedCucumberOptions(
        jsonReport = "target/81/cucumber.json",
        jsonUsageReport = "target/81/cucumber-usage.json",
        usageReport = true,
        detailedReport = true,
        detailedAggregatedReport = true,
        overviewReport = true,
        overviewChartsReport = true,
        pdfPageSize = "A4 Landscape",
        toPDF = true,
        outputFolder = "target/81",
        retryCount = 3
)
@CucumberOptions(
        features = { "/Users/sjain/THProject/src/test/java/FeatureFiles" },
        tags = { "@failed" },
        glue = "com.salesforce.trailhead.StepsDefinition", plugin = {
        "html:target/81", "json:target/81/cucumber.json",
        "pretty:target/81/cucumber-pretty.txt",
        "usage:target/81/cucumber-usage.json", "junit:target/81/cucumber-results.xml" })
public class TestRunnerRetry {

    public static int retries = 0;

    public TestRunnerRetry() {
    }
    @RetryAcceptance
    public static boolean retryCheck(Throwable e) {
        // Does not allow re-run if error message contains "Configuration failed" phrase
        return !e.getMessage().contains("Configuration failed");
    }
}
