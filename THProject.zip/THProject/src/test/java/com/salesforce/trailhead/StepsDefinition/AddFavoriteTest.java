package com.salesforce.trailhead.StepsDefinition;

import com.salesforce.trailhead.Pages.ModulePage;
import com.salesforce.trailhead.Pages.TrailHeadHomePage;
import cucumber.api.DataTable;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

/**
 * Created by sjain on 10/24/18.
 */
public class AddFavoriteTest extends BaseTrailHead{

    private BaseTrailHead baseTrailHead;
    private TrailHeadHomePage trailHeadHomePage;
    private ModulePage modulePage;
    private String moduleName;

    public AddFavoriteTest(BaseTrailHead baseTrailHead) {
        this.baseTrailHead = baseTrailHead;
        trailHeadHomePage = new TrailHeadHomePage(baseTrailHead.webdriver);
        modulePage = new ModulePage(baseTrailHead.webdriver);
    }

    @When("^User selects the Module Tab$")
    public void user_selects_the_Module_Tab() throws Throwable {
        trailHeadHomePage.clickModuleTab();
        printLogs.info("user_selects_the_Module_Tab");
    }

    @Then("^User lands on Modules page$")
    public void user_lands_on_Modules_page() throws Throwable {
        if(modulePage.isModulePageLoaded()){
            printLogs.info("user_lands_on_Modules_page");
        }else{
            printLogs.error("Module page is not loaded -  Failed");
            Assert.assertTrue(false);
        }

    }

    @When("^User select a module for adding to favorite$")
    public void user_select_a_module_for_adding_to_favorite(DataTable moduleNames) throws Throwable {
        List<Map<String,String>> data = moduleNames.asMaps(String.class,String.class);
        moduleName = data.get(0).get("ModuleName");
        boolean result  = modulePage.addFavorite(moduleName);
        if(result){
            printLogs.info("User clicked the favorite for module " + moduleName);
        }else{
            printLogs.error(" module " + moduleName + " is not found");
            Assert.assertTrue(false);
        }

    }

    @Then("^User successfully added module to favorites$")
    public void user_successfully_added_module_to_favorites() throws Throwable {
        boolean result = modulePage.verifyAddFavouriteConformationMessage();
        if(result){
            printLogs.info("Green confirmation pop is displayed");
            result &= modulePage.verifyFavoriteModule(moduleName);
            if(result){
                printLogs.info("user_successfully_added_module_to_favorites");
            }else{
                printLogs.error("Module "+moduleName + "  is not added to the favorites ");
            }
        }else{
            printLogs.error("Green confirmation pop is NOT displayed");
        }
        Assert.assertTrue(result);


    }

}
