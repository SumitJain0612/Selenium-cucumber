package com.salesforce.trailhead.StepsDefinition;


import com.salesforce.trailhead.Pages.LoginSalesforce;
import com.salesforce.trailhead.Pages.TrailHeadHomePage;
import com.salesforce.trailhead.Pages.TrailHeadPage;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

/**
 * Created by sjain on 10/23/18.
 */
public class LoginTest extends BaseTrailHead {
    private BaseTrailHead baseTrailHead;
    private TrailHeadPage trailHeadPage;
    private LoginSalesforce loginSalesForce;
    private TrailHeadHomePage trailHeadHomePage;

    public LoginTest(BaseTrailHead baseTrailHead) {
        this.baseTrailHead = baseTrailHead;
        trailHeadPage = new TrailHeadPage(baseTrailHead.webdriver);
        loginSalesForce = new LoginSalesforce(baseTrailHead.webdriver);
        trailHeadHomePage = new TrailHeadHomePage(baseTrailHead.webdriver);
    }

    @Given("^User navigates to the trailhead web page$")
    public void user_navigates_to_the_trailhead_web_page() throws Throwable {
        trailHeadPage.navigateToHomePage();
        printLogs.info("User Navigates to the trail head login page");

    }

    @And("^User clicks the login$")
    public void user_clicks_the_login() throws Throwable {
        trailHeadPage.clickOnLogin();
        waitFor(5);
        trailHeadPage.clickOnSalesforceLogin();
        printLogs.info("User Navigates to the trail head login page");

    }

    @And("^User enters the valid username$")
    public void user_enters_the_valid_username(DataTable userNames) throws Throwable {
        List<Map<String,String>> data = userNames.asMaps(String.class,String.class);
        String userName = data.get(0).get("Username");
        loginSalesForce.enterUserName(userName);
        printLogs.info("User enters the valid username");

    }

    @And("^User enters the valid password$")
    public void user_enters_the_valid_password(DataTable passwords) throws Throwable {
        List<Map<String,String>> data = passwords.asMaps(String.class,String.class);
        String password = data.get(0).get("password");
        loginSalesForce.enterPassword(password);
        printLogs.info("User enters the password");

    }

    @When("^User clicks the login button$")
    public void user_clicks_the_login_button() throws Throwable {
        loginSalesForce.clickLogin();
        printLogs.info("User clicks the login button");

    }

    @Then("^User lands on the Trailhead home page$")
    public void userLandsOnTheTrailheadHomePage() throws Throwable {
        boolean result = trailHeadHomePage.isTrailHeadHomePageLoaded();
        if(result){
            printLogs.info("User lands on trailhead home page");
        }else{
            printLogs.error("trailhead home page is not loaded");
        }
        Assert.assertTrue(result);
    }
}
