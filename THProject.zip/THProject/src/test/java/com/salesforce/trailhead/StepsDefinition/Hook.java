package com.salesforce.trailhead.StepsDefinition;

import com.salesforce.trailhead.Utils.ExtentManager;
import com.salesforce.trailhead.Utils.ExtentTestManager;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;


/**
 * Created by sjain on 10/24/18.
 */
public class Hook extends BaseTrailHead {

    private BaseTrailHead baseTrailHead;

    public Hook(BaseTrailHead baseTrailHead) {
        this.baseTrailHead = baseTrailHead;
    }

    @Before
    public void setUp(Scenario scenario){
        ExtentTestManager.startTest(scenario.getName());
        printLogs.info(scenario.getName() + " test is started");
        System.setProperty("webdriver.chrome.driver", getChromeDriverPath());
        baseTrailHead.webdriver = new ChromeDriver();
        baseTrailHead.webdriver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
        printLogs.info("Initialization of the test.. browser is opened and ready for the test");
    }

    @After
    public void tearDown(Scenario scenario){

        if(scenario.isFailed()){
            //Take a screen shot and place it at the right place so that it will show in the report
            takeScreenShot();
            printLogs.error(scenario.getName() + " is failed");

        }
        printLogs.pass(scenario.getName() + " is Completed");
        ExtentTestManager.endTest();
        ExtentManager.getInstance().flush();
        baseTrailHead.webdriver.quit();
    }
}
