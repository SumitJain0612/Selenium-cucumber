package com.salesforce.trailhead.StepsDefinition;

import com.salesforce.trailhead.Utils.PrintLogs;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

/**
 * Created by sjain on 10/24/18.
 */
public class BaseTrailHead {

    public WebDriver webdriver;
    private static String MAC_CHROME_DRIVER_PATH = "/Users/sjain/THProject/src/test/resources/com/salesforce/trailhead/Drivers/Mac/ChromeDriver/chromedriver";
    private static String WIN_CHROME_DRIVER_PATH = "src/test/resources/com/salesforce/trailhead/Drivers/Windows/ChromeDriver/chromedriver";
    private static String LINUX_CHROME_DRIVER_PATH = "src/test/resources/com/salesforce/trailhead/Drivers/Linux/ChromeDriver/chromedriver";

    PrintLogs printLogs = new PrintLogs(getClass());

//    public BaseTrailHead() {
//            System.setProperty("webdriver.chrome.driver", getChromeDriverPath());
//            this.webdriver = new ChromeDriver();
//            this.webdriver.manage().timeouts().setScriptTimeout(60, TimeUnit.SECONDS);
//    }



    public String getChromeDriverPath(){
        //this function will return the chrome drive path based on the operating system
        String chromeDriverPath = null;
        if (System.getProperty("os.name").toLowerCase().contains("mac"))
            chromeDriverPath = MAC_CHROME_DRIVER_PATH;
        if (System.getProperty("os.name").toLowerCase().contains("win"))
            chromeDriverPath = WIN_CHROME_DRIVER_PATH;
        if (System.getProperty("os.name").toLowerCase().contains("linux"))
            chromeDriverPath = LINUX_CHROME_DRIVER_PATH;
        return chromeDriverPath;
    }

    public void waitFor(int seconds){
        try {
            Thread.sleep(seconds*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void takeScreenShot(){
        //
        //
    }


}
